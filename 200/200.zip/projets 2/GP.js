var copyBtn = document.getElementById('copy');

function getPassword() {

    const chars = "0123456789abcdefghijklmnopqrstuvwxyz!@#$%^&*()ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const passwordLength = 16; // Corrected spelling: passwordLength
    let password = ""; // Use let for variables that will be reassigned

    for (let i = 0; i < passwordLength; i++) {
        const randomNumber = Math.floor(Math.random() * chars.length); // Corrected random number generation
        password += chars.charAt(randomNumber); // More efficient than substring for single characters
    }

    document.getElementById('password').value = password; // Update the input field *after* the loop
}

function copyMdp(){
    const inputPassword = document.getElementById('password');

    if(inputPassword.value.length == 16){
        inputPassword.select();
        
        copyBtn.style.background = "transparent";
        copyBtn.style.color = "#000";

        alert('mot de passe copié');
    }else{
        alert('veuillez generer un mot de passe');
    }
}copyBtn.addEventListener('click', copyMdp); 
