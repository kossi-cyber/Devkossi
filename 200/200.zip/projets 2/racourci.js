let error = document.querySelector('.error_message');
let longLink = document.querySelector('.long_link');
let short = document.querySelector('.result');
let loading = document.querySelector('.loading'); // Ajout d'un élément de chargement

function isValidUrl(url) {
    try {
        new URL(url);
        return true;
    } catch (_) {
        return false;
    }
}

function shortLinkFunct() {
    if (longLink.value !== "") {
        if (!isValidUrl(longLink.value)) {
            error.innerHTML = "URL non valide";
            short.style.display = "none";
            return;
        }

        error.innerHTML = "";
        short.style.display = "none";
        loading.style.display = "block"; // Afficher le chargement

        let url = `https://api.shrtco.de/v2/shorten?url=${encodeURIComponent(longLink.value)}`;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                loading.style.display = "none"; // Cacher le chargement
                if (data.ok && data.result && data.result.short_link) {
                    short.innerHTML = `<a href="${data.result.short_link}" target="_blank">${data.result.short_link}</a> <button onclick="copyToClipboard('${data.result.short_link}')">Copier</button>`;
                    short.style.display = "block";
                } else {
                    short.innerHTML = data.error || "Lien non valide";
                    short.style.display = "block";
                }
            })
            .catch(error => {
                loading.style.display = "none"; // Cacher le chargement
                short.innerHTML = "Une erreur s'est produite. Veuillez réessayer plus tard.";
                short.style.display = "block";
                console.error("Erreur détectée:", error);
            });
    } else {
        error.innerHTML = "Veuillez remplir le champ";
        short.style.display = "none";
    }
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert("Lien copié dans le presse-papiers!");
    }, (err) => {
        console.error('Impossible de copier le texte: ', err);
    });
}
