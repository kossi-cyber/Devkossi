function openOnglet(evt, name) {
    let i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName('tabcontent');
    for (i = 0; i < tabcontent.length; i++) { // Correction: tabcontent.length
        tabcontent[i].style.display = 'none';
    }

    tablinks = document.getElementsByClassName('tablinks');
    for (i = 0; i < tablinks.length; i++) { // Correction: tablinks.length
        tablinks[i].className = tablinks[i].className.replace(" active", ""); // Correction: Espace avant "active"
    }

    document.getElementById(name).style.display = "block";
    evt.currentTarget.className += " active"; // Correction: "active"
}