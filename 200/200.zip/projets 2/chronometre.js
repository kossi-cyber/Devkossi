let h, mn, s, ms, t, btn_stop, btn_start, sp;

//fonction pour initialiser les variables quand la page se charge

window.onload = function () {
  sp = document.getElementsByTagName('span');
  btn_start = document.getElementById('Start');

  btn_stop = document.getElementById('Stop');
  t;
  ms = 0, s = 0, mn = 0, h = 0;
}

console.log(typeof sp);


//mettre en place le compteur

function chrono() {
  ms += 1;

  if (ms == 10) {
    ms = 1;
    s += 1;
  }

  if (s == 60){
    s = 0;
    mn += 1;
  }

  if (mn == 60) {
    mn = 0;
    h += 1;
  }
// insertion des valeurs dans les spans

sp[0].innerHTML = h + "h";
sp[1].innerHTML = mn + "min";
sp[2].innerHTML = s + "s";
sp[3].innerHTML = ms + "ms";
}
//btn start
function start() {
  //execute la fonction chrono
  
  t = setInterval(chrono, 100);
  btn_start.disabled = true;
}

//btn stop
function stop() {
  clearInterval(t); //suprime l'intervale t defini plus haut
  btn_start.disabled = false;
}

//renitialiser le chrono

function reset() {
  clearInterval(t);
  btn_start.disabled = false;
  ms = 0, s = 0, mn = 0, h = 0;

  sp[0].innerHTML = 0 + "h";
sp[1].innerHTML = 0 + "min";
sp[2].innerHTML = 0+ "s";
sp[3].innerHTML = 0 + "ms";
}



