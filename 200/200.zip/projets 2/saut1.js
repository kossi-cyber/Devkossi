let perso = document.querySelector(".perso");
let obstarcle = document.querySelector(".obstarcle");

// function sauter() {
//   alert("vous avez choisire de sauter en cliquant sur start")
// }

function sauter() {
  // alert("vous aves clicke sauter");

  if (perso.classList != "animation") {
    perso.classList.add('animation');
  }

  setTimeout(function(){
    perso.classList.remove('animation');
  },500)
  // let obsta = document.querySelector('.button');
  // obsta.addEventListener('click', () => {
  //   obsta.classList.add('.animation ');
  // });

};


let verification = setInterval(function(){
  let perstop = parseInt(window.getComputedStyle(perso).getPropertyValue("top"));
  let obstarcleLeft = parseInt(window.getComputedStyle(obstarcle).getPropertyValue("left"));

  if (obstarcleLeft < 25 && perstop == 95) {
    obstarcle.style.animation = "none";
    alert("tu as perdu");
  }
});
console.log(typeof verification);

//&& obstarcleLeft > 50